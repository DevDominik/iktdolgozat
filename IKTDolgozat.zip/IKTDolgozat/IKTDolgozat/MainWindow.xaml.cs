﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using IKTDolgozat;
using System.IO;

namespace IKTDolgozat
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Tanulo> adatok = new List<Tanulo>();
        public MainWindow()
        {
            InitializeComponent();
            foreach (var item in File.ReadAllLines("naplo.txt", Encoding.UTF8))
            {
                adatok.Add(new Tanulo(item));
            }
            dgTanulok.ItemsSource = adatok;
        }

        private void btnKituno_Click(object sender, RoutedEventArgs e)
        {
            foreach (Tanulo item in adatok)
            {
                if (item.Atlag == 5)
                {
                    lbLista.Items.Add(item.Nev);
                }
            }
            
        }

        private void btnOsszatlag_Click(object sender, RoutedEventArgs e)
        {
            double atlag = 0;
            foreach (Tanulo item in adatok)
            {
                atlag += item.Atlag;
            }
            atlag /= Convert.ToDouble(adatok.Count());
            lblAtlag.Content = Math.Round(atlag, 2);
        }

        private void btnOsztalyKeres_Click(object sender, RoutedEventArgs e)
        {
            List<Tanulo> seged = new List<Tanulo>();
            foreach (Tanulo item in adatok)
            {
                if (item.Osztaly == txtOsztaly.Text.ToUpper())
                {
                    seged.Add(item);
                }
            }
            dgTanulok.ItemsSource = seged;
        }

        private void btnBukas_Click(object sender, RoutedEventArgs e)
        {
            StreamWriter fajl = new StreamWriter("figyelmeztetes.txt", true);
            foreach (Tanulo item in adatok)
            {
                if (item.Atlag < 2)
                {
                    fajl.WriteLine($"{item.Nev} {item.Atlag}");
                }
            }
        }
    }
}
